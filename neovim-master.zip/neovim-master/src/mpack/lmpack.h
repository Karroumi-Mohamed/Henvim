#include <lua.h>

int luaopen_mpack(lua_State *L);
