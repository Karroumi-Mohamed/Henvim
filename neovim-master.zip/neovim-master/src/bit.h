#include <lua.h>

int luaopen_bit(lua_State *L);
