#pragma once

#include <stddef.h>  // IWYU pragma: keep

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "base64.h.generated.h"
#endif
