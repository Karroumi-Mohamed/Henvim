#pragma once

#include "nvim/api/private/defs.h"  // IWYU pragma: keep

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "api/tabpage.h.generated.h"
#endif
